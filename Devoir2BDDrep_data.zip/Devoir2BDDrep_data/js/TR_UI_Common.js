// JavaScript Document
function TR_UI_CloseInputForm(){
	if(gbPausedWithInputList==true){
		//pick list input... make sure they selecteds something other than the introductory "pick something" option
		if(document.getElementById("InputList").selectedIndex == 0) {
			//introductory is still selected
			bPass = false;
			sDoneWrong = "You must select an option.";
		} else {
			//user selected something
			bPass = true;
		}
	} else {
		//text input... no restrictions
		bPass = true;
	}
	if(bPass) {
		document.getElementById('DivBlocker').style.display='none';
		document.getElementById('DivInputForm').style.display='none';	
		TR_Script_Run();
	} else {
		//user has done something wrong... leave the form displayed
		alert(sDoneWrong);
	}
};

function TR_UI_HandleDependentFields(oTarg,sDSVDepRules){
	//dependencies rules provided in this format DS(varname,aaa,aaa,aa)-DH(varname,bbb,bbb,bbb)
	//DS = dependend show (varname) for these answers
	//DH = dependent hide (varname) for these answers
	
	//alert(oTarg.name + " Rules:" + sDSVDepRules);
	if(sDSVDepRules.length > 0) {
		sDSVDepRules = sDSVDepRules.replace(/\)-D/g,")-*-*-D");
		aDepRules = sDSVDepRules.split("-*-*-");
		for(x=0; x<=aDepRules.length -1; x++){
			aField_values = aDepRules[x].replace(/DS\(|DH\(|\)/g,"").split(",");
			if(aDepRules[x].indexOf("DS") > -1){
				sDisplay = "";
			} else {
				sDisplay = "none";
			}
			if(oTarg.tagName.toLowerCase() == "select"){
				for(iAnswer=1; iAnswer <= aField_values.length -1; iAnswer++){
					if(oTarg.options[oTarg.selectedIndex].value == aField_values[iAnswer]){
						document.getElementById("ROW_ID_TR_" + aField_values[0]).style.display = sDisplay;
						break;
					}
				}
			}
			
			if(oTarg.tagName.toLowerCase() == "input" && oTarg.type.toLowerCase() == "radio"){
				for(iAnswer=1; iAnswer <= aField_values.length -1; iAnswer++){
					if(oTarg.value == aField_values[iAnswer]){
						document.getElementById("ROW_ID_TR_" + aField_values[0]).style.display = sDisplay;
						break;
					}
				}
			}

		}
	}
}

function TR_UP_MakeFormPassedValidations(){
	//get all the inputs from the makeform area
	oArea = document.getElementById("DivMakeFormBuildArea");
	aInputs = oArea.getElementsByTagName("input");
	sWarnings = "";
	
	//loop through all text inputs, check for validation rules and validate
	for(x=0; x<=aInputs.length -1; x++){
		if(aInputs[x].id.indexOf("ID_TR_") > -1 && aInputs[x].type != "radio"){
			//non radio inputs
			sValue = aInputs[x].value;
			sFieldName = aInputs[x].getAttribute("LabelName");

			sRowName = "ROW_" + aInputs[x].id;

			if(document.getElementById(sRowName).style.display == "") {
				//input row is visible - validate it
				aValidationCodes = aInputs[x].getAttribute("Validations").split(",");
				for(z=0; z<=aValidationCodes.length -1; z++){
					switch (aValidationCodes[z]) {
						case "P":
							//presence of some data
							if(sValue == ""){
								sWarnings+= "   - '" + sFieldName + "' must not be blank.\n";
							}
							break;
	
						case "N":
							//must be numeric
							if(isNaN(sValue) == true){
								sWarnings+= "   - '" + sFieldName + "' must be numeric.\n";
							}
							break;
	
						case "POS":
							//must be positive
							if(isNaN(sValue) == false){
								//numeric
								iValue = parseFloat(sValue);
								if(iValue <= 0) {
									//negative
									sWarnings+= "   - '" + sFieldName + "' must be positive.\n";
								}
							} else {
								//not numeric
								//sWarnings+= "   - " + sFieldName + " must be numeric.\n";
							}
							break;
	
						case "NEG":
							//must be negative
							if(isNaN(sValue) == false){
								//numeric
								iValue = parseFloat(sValue);
								if(iValue >= 0) {
									//positive
									sWarnings+= "   - '" + sFieldName + "' must be negative.\n";
								}
							} else {
								//not numeric
								//sWarnings+= "   - " + sFieldName + " must be numeric.\n";
							}
							break;
	
					}
				}
			} else {
				//field is not visible - do not validate
			}
		} else {
			//radio inputs
			if(aInputs[x].id.indexOf("ID_TR_") > -1 && aInputs[x].type == "radio"){
				sRadioGroupName = aInputs[x].name;
				aRadios = document.MakeFormBuildArea.elements[sRadioGroupName];
				sFieldName = aInputs[x].getAttribute("LabelName");

				sRowName = "ROW_" + aInputs[x].id;
				sRowName = sRowName.replace(/_[0-9]*$/,"");
				if(document.getElementById(sRowName).style.display == "") {
					//input row is visible - validate it

					bPass = false;
					for (var i=0; i < aRadios.length; i++) { 
						if (aRadios[i].checked) { 
							bPass = true; 
						} 
					} 
					if(bPass == false){
						sMessage = "   - You must check a radio button for '" + sFieldName + "'.\n"
						if(sWarnings.indexOf(sMessage) == -1) {
							sWarnings+= sMessage;
						}
					}
				} else {
					//input row is not visible - don't validate
				}
			}
		}
	}
	
	//make sure radio groups have a selection
	
	if(sWarnings.length > 0) {
		sWarnings= "Please correct the following to continue\n\n" + sWarnings;
	}
	return sWarnings;
}
function TR_UI_CloseMakeForm(){
	sValidationMessages = "";
	sValidationMessages = TR_UP_MakeFormPassedValidations();
	if(sValidationMessages == ""){
		//loop though all inputs from DivMakeFormBuildArea with ids starting with ID_TR_
		oArea = document.getElementById("DivMakeFormBuildArea");
		aInputs = oArea.getElementsByTagName("input");
		for(x=0; x<=aInputs.length -1; x++){
			//if its a text field, but the value in "VAR_TR_..."
			if(aInputs[x].id.indexOf("ID_TR_") > -1 && aInputs[x].type != "radio"){
				sRowName = "ROW_" + aInputs[x].id;
	
				sVarName = aInputs[x].id.replace(/^ID_TR_/,"VAR_TR_");
				sPrevValueVarName = aInputs[x].id.replace(/^ID_TR_/,"PREV_VAL_VAR_TR_");
				if(document.getElementById(sRowName).style.display == "") {
					window[sVarName] = aInputs[x].value;
					window[sPrevValueVarName] = aInputs[x].value;
				} else {
					window[sVarName] = "";
					window[sPrevValueVarName] = "";
				}
			}
			//if its a radio, and checked = true put the value in "VAR_TR_..."
			if(aInputs[x].id.indexOf("ID_TR_") > -1 && aInputs[x].type == "radio" && aInputs[x].checked == true){
				sVarName = aInputs[x].id
				sVarName = sVarName.replace(/^ID_TR_/,"VAR_TR_");
				sVarName = sVarName.replace(/_[0-9]*$/,"");

				sPrevValueVarName = aInputs[x].id
				sPrevValueVarName = sPrevValueVarName.replace(/^ID_TR_/,"PREV_CHKINDEX_VAR_TR_");
				sPrevValueVarName = sPrevValueVarName.replace(/_[0-9]*$/,"");

				sRowName = "ROW_" + aInputs[x].id;
				sRowName = sRowName.replace(/_[0-9]*$/,"");
				
				oRE = /[0-9]+$/;
				aCheckedIndex = oRE.exec(aInputs[x].id);
				iCheckedIndex = parseInt(aCheckedIndex[0]);

				if(document.getElementById(sRowName).style.display == "") {
					window[sVarName] = aInputs[x].value;
					window[sPrevValueVarName] = iCheckedIndex+1;
				} else {
					window[sVarName] = "";
					window[sPrevValueVarName] = "";
				}
			}
		}
		
		//loop through all selects from DivMakeFormBuildArea with ids starting with ID_TR_
		aPickLists = oArea.getElementsByTagName("select");
		for(x=0; x<=aPickLists.length -1; x++){
			if(aPickLists[x].id.indexOf("ID_TR_") > -1){
				sVarName = aPickLists[x].id.replace(/^ID_TR_/,"VAR_TR_");
				window[sVarName] = aPickLists[x].options[aPickLists[x].selectedIndex].value;
				
				sPrevValueVarName = aPickLists[x].id.replace(/^ID_TR_/,"PREV_SELINDEX_VAR_TR_");
				window[sPrevValueVarName] = aPickLists[x].selectedIndex;
			}
		}
	
		document.getElementById('DivBlocker').style.display='none';
		document.getElementById('DivMakeForm').style.display='none';	
		document.getElementById("DivMakeFormBuildArea").innerHTML = "";
		TR_Script_Run();
	} else {
		alert(sValidationMessages);
	}
}

function TR_UI_MakeForm_Validate(oTarg,sFieldName,sValidations){
	
}

function TR_UI_DebuggerToggle(oButton){
	gbDebug = !gbDebug; 
	if(gbDebug) {
		//alert("Debugging on.  Scripts will run slower.");
		oButton.style.background = "red";
		document.getElementById("DebugMessges").innerHTML = "NOTE: Scripts will run slower in debug mode."
	} else {
		//alert("Debugging off.");
		oButton.style.background = "";
	}
};

function MakeHot(oTarg){
	oTarg.className = "TopButtonHot";
}
function MakeCold(oTarg){
	oTarg.className = "TopButton";
}
function MakeNavHot(oTarg){
	oTarg.className = "NavDivHot";
}
function MakeNavCold(oTarg){
	oTarg.className = "NavDiv";
}

var goInterval;
var giX = 0;
function RandomAdjective(){
	aAdj = ",shiny,kick-butt,awesome,smoking-hot,cross-browser,spiffy,creativity-inducing,gamer-geek".split(",");
	document.getElementById("RandomAdj").innerHTML = aAdj[SimpRand(0,aAdj.length-1)];

	aSub = ",elf name,dwarf name,name,magic item,magic sword,magic potion,city,nickname,encounter,personality,heroic babe,hero,villain".split(",");
	document.getElementById("RandomSub").innerHTML = aSub[SimpRand(0,aSub.length-1)];

	aVerb = "Build,Forge,Craft,Create,Spawn".split(",");
	document.getElementById("RandomVerb").innerHTML = aVerb[SimpRand(0,aVerb.length-1)];

	clearInterval(goInterval);
	if(giX < 20) {
		//call again in 1/4 second
		goInterval = setInterval(RandomAdjective,10);
		giX++;
	} else {
		//call again in 10 seconds
		goInterval = setInterval(RandomAdjective,10000);
		giX = 0;
	}
	
}
function SimpRand (min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min; 
};
